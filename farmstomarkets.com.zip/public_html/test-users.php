<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();

// Include Supabase logic
$supabaseLogicPath = $_SERVER['DOCUMENT_ROOT'] . '/supabase_logic.php';
if (file_exists($supabaseLogicPath)) {
    require_once $supabaseLogicPath;
} else {
    die("<p>Error: Supabase logic file not found at $supabaseLogicPath.</p>");
}

// Check if Supabase variables are defined
if (!isset($supabaseKey) || !isset($restUrl) || !isset($authUrl)) {
    die("<p>Error: Supabase configuration variables (supabaseKey, restUrl, authUrl) are not defined.</p>");
}

// Check if user is signed in
if (!isset($_SESSION['access_token']) || !isset($_SESSION['user_id'])) {
    header('Location: /index.php');
    exit;
}

// Initialize variables
$message = '';

// Define available themes (aligned with CSS)
$availableThemes = [
    'original' => 'Original',
    'farmed' => 'Farmed',
    'dark' => 'Dark Mode',
    'vintage' => 'Vintage Farm',
    'modern' => 'Modern Farm'
];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $headers = getCommonHeaders($supabaseKey, $_SESSION['access_token']);

    // Get form data
    $email = trim($_POST['email'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    $theme = trim($_POST['theme'] ?? 'farmed');
    $created_at = date('c');

    // Validate required fields
    if (empty($email) || empty($name)) {
        $message = "Email and name are required.";
    } else {
        // Prepare the data for insertion
        $userData = json_encode([
            'id' => $_SESSION['user_id'], // Use the authenticated user's ID
            'email' => $email,
            'name' => $name,
            'phone_number' => $phone_number,
            'theme' => $theme,
            'created_at' => $created_at
        ]);

        // Insert the data into user_information
        $createResponse = makeHttpRequest($restUrl . '/user_information', 'POST', $headers, $userData);
        if ($createResponse === false) {
            $message = "Failed to add user information: Unable to connect to Supabase.";
        } elseif (isset($createResponse['error'])) {
            $message = "Failed to add user information: " . ($createResponse['error']['message'] ?? 'Unknown error');
        } else {
            // Update the session theme
            $_SESSION['theme'] = $theme;
            $message = "User information added successfully!";
            header('Location: /test-users.php');
            exit;
        }
    }
}

// Define page-specific variables for head.php
$pageTitle = 'FarmMarket - Add Your Information';
$pageSpecificCss = ['/css/profile.css'];

include $_SERVER['DOCUMENT_ROOT'] . '/head.php';
?>

<body data-theme="<?php echo htmlspecialchars($_SESSION['theme'] ?? 'original'); ?>">
    <!-- Include Navigation Bar -->
    <?php
    $navPath = $_SERVER['DOCUMENT_ROOT'] . '/nav.php';
    if (file_exists($navPath)) {
        include $navPath;
    } else {
        echo "<p>Error: Navigation file not found at $navPath.</p>";
    }
    ?>

    <section class="profile-content">
        <div class="profile-container">
            <h2>Add Your Information</h2>

            <?php if (!empty($message)): ?>
                <p class="<?php echo strpos($message, 'Failed') !== false ? 'failure' : 'success'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </p>
            <?php endif; ?>

            <!-- Add User Information Form -->
            <div class="profile-card">
                <div class="profile-header">
                    <h3>Add Your Information</h3>
                </div>
                <form method="POST" class="auth-form">
                    <input type="hidden" name="add_user" value="1">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter email" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" placeholder="Enter name" required>
                    </div>
                    <div class="form-group">
                        <label for="phone_number">Phone Number</label>
                        <input type="text" id="phone_number" name="phone_number" placeholder="Enter phone number">
                    </div>
                    <div class="form-group">
                        <label for="theme">Theme</label>
                        <select id="theme" name="theme">
                            <?php foreach ($availableThemes as $internalValue => $displayName): ?>
                                <option value="<?php echo htmlspecialchars($internalValue); ?>" <?php echo $internalValue === 'farmed' ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($displayName); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn">Add Information</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Include Footer -->
    <?php
    $footerPath = $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
    if (file_exists($footerPath)) {
        include $footerPath;
    } else {
        echo "<p>Error: Footer file not found at $footerPath.</p>";
    }
    ?>
</body>
</html>